# tests

This directory contains quick tests of methods that we rely on throughout this project. 

In the future, we intend to use error code to differentiate between successful and failed tests.
