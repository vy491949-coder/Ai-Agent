from aios.syscall.syscall import Syscall

class MemorySyscall(Syscall):
    pass