from aios.syscall.syscall import Syscall

class LLMSyscall(Syscall):
    pass