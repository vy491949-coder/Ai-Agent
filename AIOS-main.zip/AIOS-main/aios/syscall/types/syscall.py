from pydantic import BaseModel

class Request(BaseModel):
    pass

class Message(Request):
    pass