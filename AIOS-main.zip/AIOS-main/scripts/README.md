# scripts

## list_agents.py

List all agents available to use and install.
